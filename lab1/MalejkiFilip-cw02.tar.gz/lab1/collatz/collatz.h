#ifndef COLLATZ_H
#define COLLATZ_H

int collatz_conjecture(int input);
int test_collatz_conjecture(int input, int max_iter);

#endif